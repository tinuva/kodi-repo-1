import config

class Render(object):
    @staticmethod
    def get_render():
        if config.KODI:
            return KodiRender()
        else:
            return Render()

    def play(self, data):
        url = "%s|X-Forwarded-For=%s" % (data['url'], config.X_FORWARD_FOR)

        if 'key' in data:
            url = """#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.stream_headers=X-Forwarded-For={1}
#KODIPROP:inputstream.adaptive.license_key={0}|Content-Type=application%2Fx-www-form-urlencoded%2FX-Forwarded-For={1}|A{{SSM}}|
{2}""".format(data['key'], config.X_FORWARD_FOR, url)

        print(url)
        with open('out.strm', "w") as f:
            f.write(url)

    def items(self, items):
        for item in items:
            print(item)

class KodiRender(Render):
    def __init__(self):
        import sys
        self._handle = int(sys.argv[1])

    def play(self, data):
        import xbmcgui
        import xbmcplugin

        url = "{0}|X-Forwarded-For={1}".format(data['url'], config.X_FORWARD_FOR)
        play_item = xbmcgui.ListItem(path=url)

        if 'key' in data:
            import wvhelper
            if not wvhelper.check_inputstream():
                return

            play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            play_item.setProperty('inputstream.adaptive.stream_headers', 'X-Forwarded-For={0}'.format(config.X_FORWARD_FOR))
            play_item.setProperty('inputstream.adaptive.license_key', '{0}|Content-Type=application%2Fx-www-form-urlencoded%2FX-Forwarded-For={1}|A{{SSM}}|'.format(data['key'], config.X_FORWARD_FOR))

        xbmcplugin.setResolvedUrl(self._handle, True, play_item)

    def items(self, items):
        import xbmcgui
        import xbmcplugin

        listings = []
        for item in items:
            li = xbmcgui.ListItem(item.get('title'))

            is_folder = item.get('is_folder', True)
            if item.get('playable', False):
                is_folder = False
                li.setProperty('IsPlayable', 'true')

            li.setArt(item.get('images', {}))
            li.setInfo('video', item.get('info',{}))

            contexts = []
            for context in item.get('context', []):
                contexts.append( (context[0], "XBMC.RunPlugin({0})".format(context[1]),) )

            li.addContextMenuItems(contexts)
            listings.append((item.get('url'), li, is_folder))

        xbmcplugin.addDirectoryItems(self._handle, listings, len(listings))
        xbmcplugin.endOfDirectory(self._handle)