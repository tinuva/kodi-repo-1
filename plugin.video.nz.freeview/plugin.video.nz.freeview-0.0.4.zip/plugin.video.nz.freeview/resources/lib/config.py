import os

try:
  import xbmc, xbmcaddon
  KODI = True
except:
  KODI = False

__addonname__ = 'NZ Freeview'

if KODI:
  __addon__ = xbmcaddon.Addon()
  __data_dir__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))
  X_FORWARD_FOR = __addon__.getSetting('x_forward_for').strip()
else:
  __addon__ = None
  __data_dir__ = ''
  X_FORWARD_FOR = ''

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
DATA_FILE = 'http://iptv.matthuisman.nz/tv.json'
CACHE_FILE = os.path.join(__data_dir__, 'data.json')
CACHE_TIME = (12*60*60) #12hours
