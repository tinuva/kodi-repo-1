import requests
import json
import time
import os

import router
import config
from render import Render

class View(object):
    def __init__(self, router):
        self._router = router
        self._render = Render.get_render()

    def menu(self, params):
        items = []

        data = self._get_data()
        for station in data:
            items.append(self._parse_station(station, True))

        self._render.items(items)

    def clear_cache(self, params):
        try:
            os.remove(config.CACHE_FILE)
        except:
            pass
            
        self._render.notifcation("Cached cleared.")

    def _get_data(self):
        try:
            with open(config.CACHE_FILE, 'r') as f:
                data = json.load(f)

            if data[-1] <= time.time():
                raise Exception("Cache Expired")

            return data[:-1]
        except:
            pass

        try:
            data = requests.get(config.DATA_FILE, timeout=3).json()
        except:
            return []

        data.append(time.time() + config.CACHE_TIME)
        with open(config.CACHE_FILE, 'w') as f:
            f.write(json.dumps(data, separators=(',',':')))

        return data[:-1]

    def _parse_station(self, station, is_menu=False):
        title = station.get('name')
        image = station.get('icon')

        info = {
            'title': title,
            'originaltitle': title,
            'plot': station.get('description',''),
            'mediatype': 'musicvideo',
            'duration': 0, 
            'playcount': 0,
        }

        data = {
                'title' : title,
                'url' : station.get('url'),
                'images' : {'thumb': image, 'icon': image},
                'playable' : True,
                'info' : info,
                'video': station.get('video',{}),
                'audio': station.get('audio',{}),
                }

        if is_menu:
            data['url'] = self._router.get_route({'action': 'play', 'id': station.get('id')})

        return data

    def play(self, params):
        for item in self._get_data():
            if item.get('id') == params.get('id'):
                return self._render.play(self._parse_station(item))

        self._render.notifcation("Could not find that station.")