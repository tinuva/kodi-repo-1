import os
import sys

BASE_RESOURCE_PATH = os.path.join('.', 'resources', 'lib')
sys.path.append(BASE_RESOURCE_PATH)

from api import API
from router import Router

if __name__ == '__main__':
    api = API()
    router = Router(api, '')

  #  router.route('')
    router.route('?action=live')
  #  router.route('?action=play&vid=5008958433001&drm=0')
    #router.route('?vid=4835187443001&action=play&drm=0')
    #router.route('?action=shows')
    #router.route('?action=episodes&show=118499')
    #router.route('?vid=5394386479001&drm=0&action=play')