import config

class Render(object):
    @staticmethod
    def get_render():
        if config.KODI:
            return KodiRender()
        else:
            return Render()

    def play(self, data):
        headers = ''
        if data['url'].startswith('http') and config.X_FORWARD_FOR:
            headers = 'X-Forwarded-For=' + config.X_FORWARD_FOR
            data['url'] += '|' + headers

        if 'key' in data:
            data['url'] = """#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.stream_headers={1}
#KODIPROP:inputstream.adaptive.license_key={0}|Content-Type=application%2Fx-www-form-urlencoded%2F{1}|A{{SSM}}|
{2}""".format(data['key'], headers, data['url'])

        print(data['url'])
        with open('out.strm', "w") as f:
            f.write(data['url'])

    def items(self, items):
        for item in items:
            print(item)

    def notifcation(self, message):
        print("NOTIFCATION: %S" % message)

class KodiRender(Render):
    def __init__(self):
        import sys
        self._handle = int(sys.argv[1])

    def notifcation(self, message):
        import xbmcgui, xbmc, os
        dialog = xbmcgui.Dialog()
        dialog.notification(config.__addonname__, message, os.path.join(xbmc.translatePath(config.__addon__.getAddonInfo('path')).decode("utf-8"), 'icon.png'), 3000)

    def play(self, data):
        import xbmcgui
        import xbmcplugin

        headers = ''
        if data['url'].startswith('http') and config.X_FORWARD_FOR:
            headers = 'X-Forwarded-For=' + config.X_FORWARD_FOR
            data['url'] += '|' + headers

        play_item = xbmcgui.ListItem(path=data['url'])

        if 'key' in data:
            import wvhelper
            if not wvhelper.check_inputstream():
                return

            play_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            if headers:
                play_item.setProperty('inputstream.adaptive.stream_headers', headers)
            play_item.setProperty('inputstream.adaptive.license_key', '{0}|Content-Type=application%2Fx-www-form-urlencoded%2F{1}|A{{SSM}}|'.format(data['key'], headers))

        xbmcplugin.setResolvedUrl(self._handle, True, play_item)

    def items(self, items):
        import xbmcgui
        import xbmcplugin

        listings = []
        for item in items:
            li = xbmcgui.ListItem(item.get('title'))

            is_folder = item.get('is_folder', True)
            if item.get('playable', False):
                is_folder = False
                li.setProperty('IsPlayable', 'true')

            li.setArt(item.get('images', {}))
            li.setInfo('video', item.get('info',{}))
            li.addStreamInfo('video', item.get('video',{}))
            li.addStreamInfo('audio', item.get('audio',{}))

            contexts = []
            for context in item.get('context', []):
                contexts.append( (context[0], "XBMC.RunPlugin({0})".format(context[1]),) )

            li.addContextMenuItems(contexts)
            listings.append((item.get('url'), li, is_folder))

        xbmcplugin.addDirectoryItems(self._handle, listings, len(listings))
        xbmcplugin.endOfDirectory(self._handle)