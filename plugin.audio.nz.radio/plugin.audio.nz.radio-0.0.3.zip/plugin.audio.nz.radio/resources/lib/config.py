__addon__ = None
KODI = False

X_FORWARD_IP = '202.89.4.222'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
M3U8_FILE = 'http://files.matthuisman.nz/nzradio.m3u8'
