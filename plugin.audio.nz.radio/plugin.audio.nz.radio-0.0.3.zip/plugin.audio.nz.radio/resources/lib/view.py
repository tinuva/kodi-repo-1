import router
import config
import utils
from render import Render

class View(object):
    def __init__(self, router):
        self._router = router
        self._render = Render.get_render()

    def menu(self, params):
        items = []

        streams = utils.get_streams(config.M3U8_FILE)
        for stream in streams:
            if stream.get('url'):
                items.append(self._parse_stream(stream))

        self._render.items(items)

    def _parse_stream(self, stream):
        title = stream.get('name')
        image = stream.get('image')

        info = {
            'title': title,
            'mediatype': 'music',
        }

        stream = {
                'title' : title,
                'url' : self._router.get_route({'action': 'play', 'url': stream.get('url')}),
                'images' : {'thumb': image, 'icon': image},
                'playable' : True,
                'info' : info,
                }

        return stream

    def play(self, params):
        data = {'url': params.get('url')}
        self._render.play(data)
