import os, sys, re, shutil
from subprocess import call

if sys.version_info < (2, 7):
    import simplejson as json
else:
    import json

from . import config

def cmd(cmd):
    return call(config.__cmd__.format(cmd), shell=True)

def get_mounts():
    mounts = {}
    with open('/proc/mounts','r') as f:
        for line in f.readlines():
            mount = line.split()
            if config.__partition_pattern.match(mount[0]):
                mounts[mount[0]] = {'mount':mount[1], 'mode':mount[3]}
    print(mounts)
    return mounts

def my_partition_number():
    return partition_number(my_partition())

def write_file(file_path, content):
    temp_file = os.path.join(config.__datapath__, os.path.basename(file_path))
    with open(temp_file, 'w') as f:
        f.write(content)

    cmd('cp -rf {0} {1}'.format(temp_file, file_path))
    cmd('rm -f {0}'.format(temp_file))
    if not os.path.exists(file_path):
        raise Exception("Failed to copy file to %s" % file_path)
 
def my_partition():
    for partition, mount_info in get_mounts().iteritems():
        if mount_info['mount'] in ('/flash', '/boot'):
            return partition
    return None

def partition_mount(partition, mode='ro'):
    mount_info = get_mounts().get(partition)
    if mount_info:
        if mode == 'rw' and mount_info['mode'] == 'ro':
            cmd('umount {0}'.format(mount_info['mount']))
        else:
            return mount_info['mount']

    dst = os.path.join(config.__datapath__, os.path.basename(partition))
    if not os.path.exists(dst):
        os.mkdir(dst)
    cmd('mount -o {0} {1} {2}'.format(mode, partition, dst))

    return dst

def partition_umount(partition):
    dst = os.path.join(config.__datapath__, os.path.basename(partition))
    if os.path.exists(dst):
        cmd('umount {0}'.format(dst))
        os.rmdir(dst)

def partition_boot(partition):
    part = partition_number(partition)
    for soc in ('bcm2708','bcm2709'):
        if os.path.exists('/sys/module/{0}/parameters/reboot_part'.format(soc)):
            cmd('echo {0} > /sys/module/{1}/parameters/reboot_part'.format(part, soc))
            break

    cmd('reboot {0} || reboot'.format(part))

def partition_number(partition):
    return int(config.__partition_pattern.match(partition).group(1))

def autoboot_is(partition):
    try:
        recovery_path = partition_mount(config.__recovery_partition__, 'ro')
        autoboot = partition_number(config.__recovery_partition__)

        if os.path.exists(os.path.join(recovery_path, 'autoboot.txt')):
            with open( os.path.join(recovery_path, 'autoboot.txt'), 'r') as f:
                line = f.read().strip()

            match = re.search('boot_partition=([0-9]+)', line)
            if match:
                autoboot = int(match.group(1))

        return partition_number(partition) == autoboot
    except:
        raise
    finally:
        partition_umount(config.__recovery_partition__)

def partition_autoboot(partition):
    try:
        recovery_path = partition_mount(config.__recovery_partition__, 'rw')
        autoboot_path = os.path.join(recovery_path, 'autoboot.txt')

        if partition == config.__recovery_partition__:
            return cmd('rm -f {0}'.format(autoboot_path))

        with open(autoboot_path, 'w') as f:
            f.write('boot_partition={0}'.format(partition_number(partition)))
    except:
        raise
    finally:
        partition_umount(config.__recovery_partition__)

def get_systems():
    if not os.path.exists( config.__systems_file__ ):
        _build_systems()

    with open( config.__systems_file__ ) as f:
        return json.loads(f.read())

def get_system(system_key):
    for key, system in get_systems().iteritems():
        if key == system_key:
            return system
    return None

def save_systems(systems):
    with open( config.__systems_file__, 'w') as f:
        f.write(json.dumps(systems, indent=4, separators=(',', ': ')))

def update_system(system_key, data):
    systems = get_systems()
    for key, system in systems.iteritems():
        if key == system_key:
            system.update(data)
            break
    save_systems(systems)

def delete_data():
    cmd('rm -rf {0}'.format(config.__datapath__))

def get_system_info(system_key):
    for info in config.__systems__:
        if re.search(info['pattern'], system_key, re.IGNORECASE):
            return info
    return {}

def get_system_key(name):
    return name.replace(' ','').lower().strip()

def _build_systems():
    recovery_path = partition_mount(config.__recovery_partition__)
    settings_path = partition_mount(config.__settings_partition__)
    systems = {}

    try:
        with open( os.path.join(settings_path, 'installed_os.json') ) as f:
            raw_systems = json.loads(f.read())

        sys_name = 'NOOBS'
        try:
            with open(os.path.join(recovery_path, 'recovery.cmdline')) as f:
                data = f.read()
            if 'alt_image_source' in data or 'repo_list' in data:
                sys_name = 'PINN'
        except:
            pass

        raw_systems.append({
            'description' : 'An easy Operating System install manager for the Raspberry Pi',
            'bootable' : True,
            'partitions' : [config.__recovery_partition__],
            'name' : sys_name,
            })

        for system in raw_systems:
            if not system['bootable'] or not system['partitions']: 
                continue

            system.pop('folder', None)
            system_key = get_system_key(system['name'])
            system_info = get_system_info(system_key)

            try:
                icon_path = system_info.get('icon', None)
                if not icon_path:
                    noobs_path = system.get('icon','').replace('/mnt', recovery_path).replace('/settings', settings_path)
                    if not os.path.isfile(icon_path):
                        raise Exception("No NOOBS icon found.")

                    icon_path = os.path.join(config.__datapath__, system_key + '.png')
                    shutil.copy(noobs_path, icon_path)
            except:
                icon_path = None

            system['icon'] = icon_path
            systems[system_key] = system

        save_systems(systems)

    except:
        raise

    finally:
        partition_umount(config.__recovery_partition__)
        partition_umount(config.__settings_partition__)