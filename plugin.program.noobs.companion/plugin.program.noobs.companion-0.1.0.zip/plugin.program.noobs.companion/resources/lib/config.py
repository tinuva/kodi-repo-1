import os, re
import xbmc, xbmcaddon

__addon__        = xbmcaddon.Addon()
__addonid__      = __addon__.getAddonInfo('id').decode( 'utf-8' )
__addonversion__ = __addon__.getAddonInfo('version')
__addonname__    = __addon__.getAddonInfo('name').decode("utf-8")
__addonpath__    = __addon__.getAddonInfo('path').decode("utf-8")

__language__     = __addon__.getLocalizedString
__datapath__     = os.path.join( xbmc.translatePath( "special://profile/" ).decode( 'utf-8' ), "addon_data", __addonid__ )

__systems_file__ = os.path.join(__datapath__, 'systems.json')

__settings_partition__ = os.path.realpath('/dev/disk/by-label/SETTINGS')
__recovery_partition__ = os.path.realpath('/dev/disk/by-label/RECOVERY')

__partition_pattern = re.compile(r'^/dev/.*?([0-9]+)$')

if not os.path.exists(__datapath__):
    os.mkdir(__datapath__)

LIBREELEC = 1
OSMC = 2

if os.getuid() == 0:
    __system__ = LIBREELEC
    __cmd__ = "{0}"
else:
    __system__ = OSMC
    __cmd__ = "sudo su -c '{0}'"

__systems__ = [
    # https://downloads.raspberrypi.org/os_list_v3.json #
    {'pattern': 'LibreELEC', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/libreelec.png'},
    {'pattern': 'OSMC', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/osmc.png'},
    {'pattern': 'Lakka', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/lakka.png', 'boot-back': 'lakka'},
    {'pattern': 'RaspbianLite', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/raspbian.png'},
    {'pattern': 'Raspbian', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/raspbian.png', 'boot-back': 'raspbian'},
    {'pattern': 'recalbox', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/recalboxos.png', 'boot-back': 'recalbox'},
    {'pattern': 'RISC', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/riscos.png'},
    {'pattern': 'Windows', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/windows10iotcore.png'},
    {'pattern': 'TLXOS', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/tlxos.png'},

    # https://raw.githubusercontent.com/procount/pinn-os/master/os/os_list_v3.json #
    {'pattern': 'AIYprojects', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/aiyprojects.png'},
    {'pattern': 'CStemBian', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/cstembian.png'},
    {'pattern': 'PiTop', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/pitop.png'},
    {'pattern': 'solydx', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/solydx.png'},
    {'pattern': 'ubuntuMate1604LTS', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/ubuntu-mate.png'},
    {'pattern': 'OpenELEC', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/openelec.png'},
    {'pattern': 'XBian', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/xbian.png'},
    {'pattern': 'Retropie', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/retropie.png', 'boot-back': 'retropie'},
    {'pattern': 'kali2', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/kali.png'},
    {'pattern': 'rtandroid', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/rtandroid.png'},
    {'pattern': 'lede2', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/lede2.png'},
    {'pattern': 'Arch', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/arch.png'},
    {'pattern': 'void', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/void.png'},

    # https://bitbucket.org/matthuisman/pinn-os/raw/master/os_list_v3.json #
    {'pattern': 'batocera', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/batocera.png', 'boot-back': 'batocera'},
    {'pattern': 'Kano_OS', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/kano_os.png'},
    {'pattern': 'RasPlex', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/rasplex.png'},

    # Built-in
    {'pattern': 'NOOBS', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/noobs.png'},
    {'pattern': 'PINN', 'icon': 'https://bytebucket.org/matthuisman/files/raw/master/logos/noobs-companion/pinn.png'},
]