﻿# coding=utf-8
from __future__ import absolute_import

import os, time, traceback
from urlparse import parse_qsl

import xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs

from resources.lib import util
from resources.lib import config

dialog = xbmcgui.Dialog()

def boot_system(system_name):
    system_key = util.get_system_key(system_name)
    system = util.get_system(system_key)
    if not system:
        dialog.notification(config.__addonname__, 'Could not find system: {0}'.format(system_name), os.path.join(config.__addonpath__, 'icon.png'), 3000)
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    if system_key == 'noobs' and not util.autoboot_is(system.get('partitions')[0]):
        if not dialog.yesno(name, 'NOOBS needs to be set to Autoboot to allow NOOBS to boot.','','Set NOOBS to Autoboot?'):
            return

        util.partition_autoboot(system.get('partitions')[0])

    dialog.notification(name, 'Booting....', icon, 2000)
    time.sleep(1)
    try:
        util.partition_boot(system.get('partitions')[0])
    except:
        traceback.print_exc()
        dialog.notification(name, 'Error Booting', icon, 5000)

def install_system(system_key):
    from resources.lib import install

    system = util.get_system(system_key)
    if not system:
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    function = getattr(install, util.get_system_info(system_key).get('boot-back', ''), None)
    if not function:
        dialog.notification(name, 'Currently not Boot-Back installable.', icon, 5000)
        return

    try:
        function(system.get('partitions'))
    except:
        traceback.print_exc()
        dialog.notification(name, 'Error Installing Boot-Back', icon, 5000)
    else:
        dialog.notification(name, 'Boot-Back Installed', icon, 2000)
        xbmc.executebuiltin('Container.Refresh')

def autoboot_system(system_key):
    system = util.get_system(system_key)
    if not system:
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    # Temp warning until autoboot in NOOBS / PINN is fixed.
    if system.get('partitions')[0] != config.__recovery_partition__ and not dialog.yesno('WARNING', 'Autoboot is currently broken for most systems in NOOBS / PINN. Using it can even cause your system not to boot (fix by deleting the autoboot.txt file).\nDo you still want to set Autoboot?'):
        return

    try:
        util.partition_autoboot(system.get('partitions')[0])
    except:
        traceback.print_exc()
        dialog.notification(name, 'Error setting Autoboot', icon, 5000)
    else:
        dialog.notification(name, 'Set to Autoboot', icon, 2000)

def rename_system(system_key):
    system = util.get_system(system_key)
    if not system:
        return

    kb = xbmc.Keyboard()
    kb.setHeading('Rename system')
    kb.setDefault(system.get('name',''))
    kb.doModal()
    if not kb.isConfirmed():
        return

    new_name = kb.getText()
    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    try:
        util.update_system(system_key, {'name' : new_name})
    except:
        traceback.print_exc()
        dialog.notification(name, 'Error setting sytem name', icon, 5000)
    else:
        xbmc.executebuiltin('Container.Refresh')

def set_icon_system(system_key):
    system = util.get_system(system_key)
    if not system:
        return

    new_icon = dialog.browseSingle(2, 'Choose a new icon', 'files')
    if not new_icon:
        return

    name = system.get('name', '')
    icon = system.get('icon', xbmcgui.NOTIFICATION_INFO)

    try:
        util.update_system(system_key, {'icon' : new_icon})
    except:
        traceback.print_exc()
        dialog.notification(name, 'Error setting icon', icon, 5000)
    else:
        xbmc.executebuiltin('Container.Refresh')

def rebuild_systems():
    if dialog.yesno('Rebuild Systems?', 'This will delete the current config and rebuild it.\nYou will lose any custom names / icons you have set.', ):
        util.delete_data()
        dialog.notification(config.__addonname__, 'Systems have been rebuilt', os.path.join(config.__addonpath__, 'icon.png'), 3000)

def list_systems():
    systems = util.get_systems()

    for system_key, system in systems.iteritems():
        listitem = xbmcgui.ListItem( label=system['name'], thumbnailImage=system['icon'] )

        context_items = [
            ( 'Rename', "XBMC.RunPlugin({0}?action=rename&system={1})".format(sys.argv[0], system_key) ),
            ( 'Set Icon', "XBMC.RunPlugin({0}?action=set_icon&system={1})".format(sys.argv[0], system_key) ),
            ( 'Set to Autoboot', "XBMC.RunPlugin({0}?action=autoboot&system={1})".format(sys.argv[0], system_key) ),
        ]

        if util.get_system_info(system_key).get('boot-back', None):
            context_items.extend((
                ( 'Install Boot-Back', "XBMC.RunPlugin({0}?action=install&system={1})".format(sys.argv[0], system_key) ),
            ))

        listitem.addContextMenuItems(context_items)

        action = "{0}?action=boot&system={1}".format(sys.argv[0], system_key)
        xbmcplugin.addDirectoryItem( int(sys.argv[1]), action, listitem, isFolder=False )

    xbmcplugin.endOfDirectory( int(sys.argv[1]) )

params = dict(parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if action == 'boot':
    boot_system(params.get('system'))

elif action == 'install':
    install_system(params.get('system'))

elif action == 'autoboot':
    autoboot_system(params.get('system'))

elif action == 'rename':
    rename_system(params.get('system'))

elif action == 'set_icon':
    set_icon_system(params.get('system'))

elif action == 'rebuild':
    rebuild_systems()

else:
    list_systems()