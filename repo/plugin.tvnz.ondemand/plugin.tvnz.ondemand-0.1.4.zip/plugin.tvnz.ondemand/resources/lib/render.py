import sys, os
import config
if config.KODI:
    import xbmc, xbmcgui, xbmcplugin, wvhelper

class Render(object):
    @staticmethod
    def get_render():
        if config.KODI:
            return KodiRender()
        else:
            return Render()

    def get_query(self):
        return " street "

    def error(self, message):
        print("ERROR: {0}".format(message))

    def play(self, data):
        headers = ''
        if data['url'].startswith('http') and config.X_FORWARD_FOR:
            headers = 'X-Forwarded-For=' + config.X_FORWARD_FOR
            data['url'] += '|' + headers

        if 'key' in data:
            data['url'] = """#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.stream_headers={1}
#KODIPROP:inputstream.adaptive.license_key={0}|Content-Type=application%2Fx-www-form-urlencoded%2F{1}|A{{SSM}}|
{2}""".format(data['key'], headers, data['url'])

        print(data['url'])
        with open('out.strm', "w") as f:
            f.write(data['url'])

    def reinstall(self):
        print("Reinstalling....")
        return True

    def get_username(self):
        return input("Enter TVNZ Username / Email: ")

    def get_password(self):
        return input("Enter TVNZ Password: ")

    def items(self, items):
        for item in items:
            print(item)

    def refresh(self):
        print("Refresh")

    def notifcation(self, message):
        print("NOTIFCATION: %S" % message)

class KodiRender(Render):
    def __init__(self):
        self._handle = int(sys.argv[1])

    def reinstall(self):
        dialog = xbmcgui.Dialog()
        if dialog.yesno('Reinstall DRM?', 'This will delete the current DRM and attempt to reinstall it.'):
            wvhelper.check_inputstream(reinstall=True)

    def refresh(self):
        xbmc.executebuiltin('Container.Refresh')

    def notifcation(self, message):
        dialog = xbmcgui.Dialog()
        dialog.notification(config.__addonname__, message, os.path.join(xbmc.translatePath(config.__addon__.getAddonInfo('path')).decode("utf-8"), 'icon.png'), 3000)

    def get_query(self):        
        kb = xbmc.Keyboard ('', 'Search', False)
        kb.doModal()
        if (kb.isConfirmed()):
            return kb.getText()
        return None

    def get_username(self, default=''):
        dialog = xbmcgui.Dialog()
        return dialog.input('Enter your TVNZ Username / Email', default, xbmcgui.INPUT_ALPHANUM)

    def get_password(self):
        dialog = xbmcgui.Dialog()
        return dialog.input('Enter your TVNZ Password', '', xbmcgui.INPUT_ALPHANUM, xbmcgui.ALPHANUM_HIDE_INPUT)

    def error(self, message):
        dialog = xbmcgui.Dialog()
        dialog.ok('ERROR', message)

    def play(self, data):
        headers = ''
        if data['url'].startswith('http') and config.X_FORWARD_FOR:
            headers = 'X-Forwarded-For=' + config.X_FORWARD_FOR
            data['url'] += '|' + headers

        li = xbmcgui.ListItem(path=data['url'])

        if 'key' in data:
            if not wvhelper.check_inputstream():
                return

            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            if headers:
                li.setProperty('inputstream.adaptive.stream_headers', headers)
            li.setProperty('inputstream.adaptive.license_key', '{0}|Content-Type=application%2Fx-www-form-urlencoded%2F{1}|A{{SSM}}|'.format(data['key'], headers))

        xbmcplugin.setResolvedUrl(self._handle, True, li)

    def _create_list_item(self, data):
        li = xbmcgui.ListItem(data.get('title'))
        li.setPath(data.get('url'))

        if data.get('playable', False):
            li.setProperty('IsPlayable', 'true')

        li.setArt(data.get('images', {}))
        li.setInfo('video', data.get('info',{}))
        li.addStreamInfo('video', data.get('video',{}))
        li.addStreamInfo('audio', data.get('audio',{}))

        contexts = []
        for context in data.get('context', []):
            contexts.append( (context[0], "XBMC.RunPlugin({0})".format(context[1]),) )

        li.addContextMenuItems(contexts)
        return li

    def items(self, items):
        listings = []
        for item in items:
            li = self._create_list_item(item)
            is_folder = item.get('is_folder', True) and not item.get('playable', False)
            xbmcplugin.addDirectoryItem(self._handle, item.get('url'), li, is_folder)

        xbmcplugin.endOfDirectory(self._handle)