import os, platform, shutil, requests, traceback
import xbmc, xbmcgui, xbmcaddon
import config

system_ = platform.system()
arch = platform.machine()
if arch[:3] == 'arm':
    arch = arch[:5]

if arch == 'i686':
    arch = 'i386'

if system_ == 'Linux' and xbmc.getCondVisibility('system.platform.android'):
    system_ = 'Android'

if system_+arch in config.SUPPORTED_PLATFORMS:
    supported = True
else:
    supported = False

cdm_path = None
addon = None

def check_inputstream(reinstall=False):
    global cdm_path, addon

    if not supported and config.__addon__.getSetting('skip_drm') != 'true':
        print("Not supported: %s" % system_+arch)
        xbmcgui.Dialog().ok('Not Supported', 'This system is not supported for DRM content playback.')
        return False

    def get_addon():
        try:
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"inputstream.adaptive","enabled":false}}')
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"inputstream.adaptive","enabled":true}}')
            return xbmcaddon.Addon('inputstream.adaptive')
        except:
            return False

    addon = get_addon()
    if not addon:
        xbmc.executebuiltin('InstallAddon(inputstream.adaptive)', True)

        addon = get_addon()
        if not addon:
            xbmcgui.Dialog().ok('Missing inputstream.adaptive add-on',
                                'inputstream.adaptive VideoPlayer InputStream add-on \
                                not found or not enabled. This add-on is required to \
                                view DRM protected content.')
            return False

    cdm_path = xbmc.translatePath(addon.getSetting('DECRYPTERPATH'))
    if not os.path.isdir(cdm_path):
        os.makedirs(cdm_path)

    if system_ == 'Android':
        return True

    try:
        installed = False

        if reinstall or not is_widevinecdm():
            get_widevinecdm()
            installed = True

        if reinstall or not is_ssd_wv():
            get_ssd_wv()
            installed = True
    except:
        traceback.print_exc()
        xbmcgui.Dialog().ok('ERROR', 'There was an error checking / installing DRM.')
        return False

    if installed:
        xbmcgui.Dialog().ok('DRM installed OK.', 'If videos still won\'t play - please try restarting KODI.')

    return True

def is_widevinecdm():
    return os.path.exists(os.path.join(cdm_path, config.WIDEVINECDM_DICT[system_]))

def is_ssd_wv():
    return os.path.exists(os.path.join(cdm_path, config.SSD_WV_DICT[system_]))

def get_widevinecdm():
    filename = config.WIDEVINECDM_DICT[system_]
    url = config.GIT_URL.format(system_, arch, filename)

    download_path = os.path.join(cdm_path, filename)
    if os.path.exists(download_path):
        os.remove(download_path)

    if not progress_download(url, download_path, filename):
        raise Exception("Failed to download file")

    os.chmod(download_path, 0755)

def get_ssd_wv():
    filename = config.SSD_WV_DICT[system_]
    url = config.GIT_URL.format(system_, arch, filename)

    download_path = os.path.join(cdm_path, filename)
    if os.path.exists(download_path):
        os.remove(download_path)

    addon_path = xbmc.translatePath(addon.getAddonInfo('path')).decode("utf-8")
    paths = [os.path.join(addon_path,'lib',filename), os.path.join(os.sep,'usr','lib',filename)]
    for path in paths:
        if os.path.exists(path):
            try:
                os.symlink(path, download_path)
                os.chmod(download_path, 0755)
                return
            except:
                try:
                    shutil.copy(path, download_path)
                    os.chmod(download_path, 0755)
                    return
                except:
                    continue
        
    if not progress_download(url, download_path, filename):
        raise Exception("Failed to download file")

    os.chmod(download_path, 0755)
    
def progress_download(url, download_path, filename):
    xbmc.log('Downloading {0}'.format(url),xbmc.LOGNOTICE)
    try:
        res = requests.get(url, stream=True, verify=False)
        res.raise_for_status()
    except requests.exceptions.HTTPError:
        xbmcgui.Dialog().ok('Download failed', 'HTTP '+str(res.status_code)+' error')
        xbmc.log('Error retrieving {0}'.format(url), level=xbmc.LOGNOTICE)
        return False

    total_length = float(res.headers.get('content-length'))
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading {0}".format(filename),
              "Downloading File",url)

    with open(download_path, 'wb') as f:
        chunk_size = 1024
        downloaded = 0
        for chunk in res.iter_content(chunk_size=chunk_size):
            f.write(chunk)
            downloaded += len(chunk)
            percent = int(downloaded*100/total_length)
            if dp.iscanceled():
                dp.close()
                res.close()
            dp.update(percent)

    xbmc.log('Download {0} bytes complete, saved in {1}'.format(
                int(total_length), download_path),xbmc.LOGNOTICE)

    dp.close()
    return True