try:
  import xbmcaddon
  KODI = True
except:
  KODI = False

if KODI:
  __addon__ = xbmcaddon.Addon()
  X_FORWARD_FOR = __addon__.getSetting('x_forward_for').strip()
else:
  __addon__ = None
  X_FORWARD_FOR = ''

__addonname__ = "TVNZ OnDemand"

MENU = [
  {'title':'A-Z', 'url':{'action':'a_to_z'}, 'image':None},
  {'title':'GENRE', 'url':{'action':'genre'}, 'image':None},
  {'title':'SEARCH', 'url':{'action':'search'}, 'image':None},
  {'title':'LIVE', 'url':{'action':'live'}, 'image':None},
]

LIVE_MENU = [
  {'title':'TVNZ 1', 'url':{'action':'play','channel':'tvnz-1','title':'TVNZ 1'}, 'image':'https://bytebucket.org/matthuisman/files/raw/master/logos/tv/9.png', 'playable':True},
  {'title':'TVNZ 2', 'url':{'action':'play','channel':'tvnz-2','title':'TVNZ 2'}, 'image':'https://bytebucket.org/matthuisman/files/raw/master/logos/tv/10.png', 'playable':True},
  {'title':'DUKE', 'url':{'action':'play','channel':'tvnz-duke','title':'DUKE'}, 'image':'https://bytebucket.org/matthuisman/files/raw/master/logos/tv/55.png', 'playable':True},
]

LOGGED_IN = [
  # {'title':'MY SHOWS', 'url':{'action':'myshows'}, 'image':None},
  # {'title':'WATCHLIST', 'url':{'action':'watchlist'}, 'image':None},
  # {'title':'HISTORY', 'url':{'action':'history'}, 'image':None},
  # {'title':'LOGOUT', 'url':{'action':'logout'}, 'image':None},
]

LOGGED_OUT = [
  # {'title':'LOGIN', 'url':{'action':'login'}, 'image':None},
  # {'title':'REGISTER', 'url':{'action':'register'}, 'image':None},
]

BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{0}/videos/{1}'
BRIGHTCOVE_KEY = 'BCpkADawqM0IurzupiJKMb49WkxM__ngDMJ3GOQBhN2ri2Ci_lHwDWIpf4sLFc8bANMc-AVGfGR8GJNgxGqXsbjP1gHsK2Fpkoj6BSpwjrKBnv1D5l5iGPvVYCo'
BRIGHTCOVE_ACCOUNT = '963482467001'

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'

API_BASE_URL = 'https://api.tvnz.co.nz'

GIT_URL = 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/{0}/{1}/{2}'

SSD_WV_DICT = {
              'Windows': 'ssd_wv.dll',
              'Linux': 'libssd_wv.so',
              'Darwin': 'libssd_wv.dylib'
              }

WIDEVINECDM_DICT = { 
                    'Windows': 'widevinecdm.dll',
                    'Linux': 'libwidevinecdm.so',
                    'Darwin': 'libwidevinecdm.dylib'
                    }
                     
SUPPORTED_PLATFORMS = [ 
                      'WindowsAMD64',
                      'Windowsx86',
                      'Darwinx86_64',
                      'Linuxx86_64',
                      'Linuxi386',
                      'Linuxarmv7',
                      'Linuxarmv8'
                      ]