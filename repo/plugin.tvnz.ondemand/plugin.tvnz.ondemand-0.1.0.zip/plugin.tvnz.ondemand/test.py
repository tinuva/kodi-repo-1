import os
import sys

BASE_RESOURCE_PATH = os.path.join('.', 'resources', 'lib')
sys.path.append(BASE_RESOURCE_PATH)

from api import API
from router import Router

if __name__ == '__main__':
    api = API('tvnz.cookie')
    router = Router(api, '')

    #router.route('?action=myshows')
    #router.route('?remove=%2Fcontent%2Ftvnz%2Fondemand%2Fshows%2Fa%2Faquarius&action=myshows')
    router.route('?action=play&title=&channel=tvnz-1')
   # router.route('?action=a_to_z')
    #router.route('?action=search')
   # router.route('?action=show&path=%2fcontent%2ftvnz%2fondemand%2fshows%2fs%2fshortland-street')
    #router.route('?action=belt&path=%2Fcontent%2Ftvnz%2Fondemand%2Fshows%2Fjcr%3Acontent%2FcontentArea%2Fabcbelt_22')
    #router.route('?action=show&path=/content/tvnz/ondemand/shows/s/shortland-street')
 #   router.route('?action=play&brightcoveId=5435795717001')
   # router.route('?action=show&path=%2fcontent%2ftvnz%2fondemand%2fshows%2fs%2fsurvivor-new-zealand')