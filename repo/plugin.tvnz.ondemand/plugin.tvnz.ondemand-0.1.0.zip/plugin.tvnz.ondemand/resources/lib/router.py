try:
    from urlparse import parse_qsl #python2
    from urllib import urlencode
except:
    from urllib.parse import parse_qsl #python3
    from urllib.parse import urlencode

from view import View

class Router(object):
    def __init__(self, api, base_url):
        self._view = View(api, self)
        self._base_url = base_url

    def route(self, paramstring):
        params = dict(parse_qsl(paramstring[1:]))
        action = params.get('action')
        if action == 'a_to_z':
            self._view.a_to_z()
        elif action == 'belt':
            self._view.belt(params.get('path'))
        elif action == 'play':
            self._view.play(params)
        elif action == 'search':
            self._view.search()
        elif action == 'show':
            self._view.show(params)
        elif action == 'genre':
            self._view.genre(params)
        elif action == 'reinstall':
            self._view.reinstall()
        elif action == 'login':
            self._view.login(params)
        elif action == 'logout':
            self._view.logout(params)
        elif action == 'myshows':
            self._view.myshows(params)
        else:
            self._view.menu()

    def get_route(self, params):
        return self._base_url + "?" + urlencode(params)