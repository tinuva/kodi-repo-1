try:
  import xbmcaddon
  KODI = True
except:
  KODI = False

if KODI:
  __addon__ = xbmcaddon.Addon()
  X_FORWARD_FOR = __addon__.getSetting('x_forward_for').strip()
else:
  __addon__ = None
  X_FORWARD_FOR = ''

__addonname__ = "TVNZ OnDemand"

MENU = [
  {'title':'A-Z', 'url':{'action':'a_to_z'}, 'image':None},
  {'title':'GENRE', 'url':{'action':'genre'}, 'image':None},
  {'title':'SEARCH', 'url':{'action':'search'}, 'image':None},
  {'title':'TVNZ ONE', 'url':{'action':'play','channel':'tvnz-1','title':'TVNZ ONE'}, 'image':None, 'playable':True},
  {'title':'TVNZ TWO', 'url':{'action':'play','channel':'tvnz-2','title':'TVNZ TWO'}, 'image':None, 'playable':True},
  {'title':'TVNZ DUKE', 'url':{'action':'play','channel':'tvnz-duke','title':'DUKE'}, 'image':None, 'playable':True},
]

LOGGED_IN = [
  # {'title':'MY SHOWS', 'url':{'action':'myshows'}, 'image':None},
  # {'title':'WATCHLIST', 'url':{'action':'watchlist'}, 'image':None},
  # {'title':'HISTORY', 'url':{'action':'history'}, 'image':None},
  # {'title':'LOGOUT', 'url':{'action':'logout'}, 'image':None},
]

LOGGED_OUT = [
  # {'title':'LOGIN', 'url':{'action':'login'}, 'image':None},
  # {'title':'REGISTER', 'url':{'action':'register'}, 'image':None},
]

BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{0}/videos/{1}'
BRIGHTCOVE_KEY = 'BCpkADawqM0IurzupiJKMb49WkxM__ngDMJ3GOQBhN2ri2Ci_lHwDWIpf4sLFc8bANMc-AVGfGR8GJNgxGqXsbjP1gHsK2Fpkoj6BSpwjrKBnv1D5l5iGPvVYCo'
BRIGHTCOVE_ACCOUNT = '963482467001'

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'

API_BASE_URL = 'https://api.tvnz.co.nz'

SSD_WV_REPO = "https://bitbucket.org/matthuisman/decryptmodules/raw/master/"

WIDEVINECDM_URL = { 'Linuxx86_64': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Linux/x86_64/libwidevinecdm.so',
                    'Linuxarmv7': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Linux/armv7/libwidevinecdm.so',
                    'Linuxarmv8': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Linux/armv8/libwidevinecdm.so',
                    'Darwinx86_64': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Darwin/x86_64/libwidevinecdm.dylib',
                    'WindowsAMD64': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Windows/AMD64/widevinecdm.dll',
                    'Windowsx86': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Windows/x86/widevinecdm.dll',
                    }

UNARCHIVE_COMMAND = { 'Linuxx86_64': "(cd {1} && chmod 755 {1}/{2})",
                      'Linuxarmv7': "(cd {1} && chmod 755 {1}/{2})",
                      'Linuxarmv8': "(cd {1} && chmod 755 {1}/{2})",
                      }

SSD_WV_DICT = { 'Windows': 'ssd_wv.dll',
                'Linux': 'libssd_wv.so',
                'Darwin': 'libssd_wv.dylib'}

WIDEVINECDM_DICT = { 'Windows': 'widevinecdm.dll',
                     'Linux': 'libwidevinecdm.so',
                     'Darwin': 'libwidevinecdm.dylib'}
                     
SUPPORTED_PLATFORMS = [ 'WindowsAMD64',
                        'Windowsx86',
                        'Darwinx86_64',
                        'Linuxx86_64',
                        'Linuxarmv7',
                        'Linuxarmv8']