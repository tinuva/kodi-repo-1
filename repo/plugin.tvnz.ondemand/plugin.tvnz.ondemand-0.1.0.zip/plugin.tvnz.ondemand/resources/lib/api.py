try:
    from cookielib import LWPCookieJar #Python2
except:
    from http.cookiejar import LWPCookieJar #Python3

import requests
import os
import config
import re

try:
    import StringIO #python2
except:
    import io as StringIO #python3

class API(object):
    _logged_in = False
    _url = config.API_BASE_URL+'/api{0}.androidtablet.v8.json'
    _cookie_path = ''

    def __init__(self, cookiepath):
        self._cookie_path = cookiepath

        self._session  = requests.Session()
        self._session.headers.update({
            'BCOV-POLICY': config.BRIGHTCOVE_KEY, 
            'User-Agent' : config.USER_AGENT,
            'X-Forwarded-For': config.X_FORWARD_FOR,
            })

        self._load_cookies()

    def widevine_auth(self, program_id):
        brightcove_url = config.BRIGHTCOVE_URL.format(config.BRIGHTCOVE_ACCOUNT, program_id)
        program_data = self._session.get(brightcove_url).json()

        if 'sources' not in program_data:
            if 'message' in program_data[0]:
                message = program_data[0]['message']
            elif 'error_code' in program_data[0]:
                message = program_data[0]['error_code']
            else:
                message = "Unknown error"
            return {'error': message}

        for source in program_data['sources']:
            if source.get('container') == None:
                if 'key_systems' in source:
                    if 'com.widevine.alpha' in source['key_systems']:
                        return {'program': program_data, 'url':source['src'], 'key':source['key_systems']['com.widevine.alpha']['license_url']}

        return {'error': 'Could not find DRM key'}

    def get_m3u8(self, url, max_bandwith=None):
        infile = StringIO.StringIO(self._session.get(url).text)
        if not infile.readline().lower().startswith('#extm3u'):
           raise

        videos = []
        video = {}
        for line in infile:
            line=line.strip()

            if line.startswith('#EXT-X-STREAM-INF:'):
                # pull length and title from #EXTINF line
                pattern = re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
                params = pattern.split(line.replace('#EXT-X-STREAM-INF:', ''))[1::2]

                for param in params:
                    name, value = param.split('=', 1)
                    video[name.lower()] = value

            elif(line == '' or line.startswith('#')):
                continue

            else:
                video['url'] = line
                videos.append(video)
                video = {}

        videos = sorted(videos, key=lambda k: int(k.get('bandwidth', 0)), reverse=True)
        for video in videos:
            if max_bandwith == None or int(video.get('bandwidth'),0) <= max_bandwith:
                return video

        #all videos higher bandwith, so return the last in the list (lowest bandwith)
        return video

    def get_path(self, path, require_login=False):
        url = self._url.format(path)
        print(url)
        r = self._session.get(url)
        r.encoding = 'ISO-8859-1'
        if r.text:
            return r.json()
        raise Exception("Error getting path")

    def delete_path(self, path, data, require_login=False):
        url = self._url.format(path)
        r = self._session.delete(url, json=data)
        return (r.status_code in (200,202))

    def put_path(self, path, data, require_login=False):
        url = self._url.format(path)
        r = self._session.put(url, json=data)
        return (r.status_code in (200,202))

    def _save_cookies(self):
        if isinstance(self._session.cookies, LWPCookieJar):
            self._session.cookies.save()

    # def menu(self):
    #     return self._get_path('/config/ondemand/menu')

    @property
    def logged_in(self):
        return self._logged_in

    def _load_cookies(self):
        if self._cookie_path:
            self._session.cookies = LWPCookieJar(self._cookie_path)
            if os.path.isfile(self._cookie_path):
                self._session.cookies.load(ignore_discard=True)
                self._logged_in = True

    def login(self, username, password):
        try:
            payload = {
                'username':username,
                'password':password,
                'keepLoggedIn':True,
            }

            r = self._session.post('https://api.tvnz.co.nz/api/content/tvnz/ondemand/login/androidtablet/j_tvnz_security_check?j_validate=true', json=payload, allow_redirects=False)
            if r.status_code != 200:
                raise Exception("Failed to login")

            self._logged_in = True

            self._save_cookies()
            return True
        except:
            self.logout()
            return False

    def logout(self):
        self._session.cookies.clear()
        if os.path.isfile(self._cookie_path):
            os.remove(self._cookie_path)
        self._logged_in = False


# public interface TvnzApiService {
#     @GET("/api/content/tvnz/ondemand/api.config.all.json")
#     Observable<DateFormatter> m4051a();

#     @GET("/api{path}/{count}/{from}.{device}.{api}.json")
#     Observable<FilteredArrayList<BeltItem>> m4052a(@Path(encode = false, value = "path") String str, @Path("count") int i, @Path("from") int i2, @Path("device") String str2, @Path("api") String str3);

#     @GET("/api/content/tvnz/ondemand/registration/house-rules.{device}.{version}.json")
#     Observable<TermsAndConditionDto> m4053a(@Path("device") String str, @Path("version") String str2);

#     @GET("/api{path}.{device}.{api}.json")
#     Observable<List<TvnzJsonObject>> m4054a(@Path(encode = false, value = "path") String str, @Path("device") String str2, @Path("api") String str3);

#     @GET("/api/v1/android/ondemand/config/segment")
#     Observable<SegmentGAConfig> m4055b();

#     @GET("/api/content/tvnz/ondemand/help/faqs.{device}.{api}.json")
#     Observable<List<FAQ>> m4056b(@Path("device") String str, @Path("api") String str2);

#     @GET("/api/content/tvnz/ondemand/shows/search/{phrase}.{device}.{api}.json")
#     Observable<List<SearchResult>> m4057b(@Path("phrase") String str, @Path("device") String str2, @Path("api") String str3);

#     @GET("/api/config/ondemand/menu.{device}.{api}.json")
#     Observable<List<MenuItem>> m4058c(@Path("device") String str, @Path("api") String str2);

#     @GET("/api/content/tvnz/ondemand/channels/{channelname}.{device}.{api}.json")
#     Observable<List<TvnzJsonObject>> m4059c(@Path("device") String str, @Path("api") String str2, @Path("channelname") String str3);
# }

# public interface TvnzProfileApiService {
#     @GET("/system/sling/logout")
#     Observable<Response> m4060a();

#     @GET("/api/session/tvnz/ondemand/user.{device}.{api}.json")
#     Observable<UserProfile> m4061a(@Path("device") String str, @Path("api") String str2);

#     @DELETE_WITH_BODY("/api/session/tvnz/ondemand/my-shows/history.{device}.{api}.json")
#     Observable<SavedItemResponseDto> m4062a(@Path("device") String str, @Path("api") String str2, @Body AssetPathDto assetPathDto);

#     @POST("/api/session/tvnz/ondemand/user/subscription/update.{device}.{api}.json")
#     Observable<Response> m4063a(@Path("device") String str, @Path("api") String str2, @Body EndpointDto endpointDto);

#     @PUT("/api/session/tvnz/ondemand/my-shows/history.{device}.{api}.json")
#     Observable<SavedItemResponseDto> m4064a(@Path("device") String str, @Path("api") String str2, @Body HistoryItemDto historyItemDto);

#     @PUT("/api/session/tvnz/ondemand/user.{device}.{api}.json")
#     Observable<RegisterResultDto> m4065a(@Path("device") String str, @Path("api") String str2, @Body UserDto userDto);

#     @POST("/api/session/tvnz/ondemand/user.{device}.{api}.json")
#     Observable<SuccessDto> m4066a(@Path("device") String str, @Path("api") String str2, @Body UserUpdateDto userUpdateDto);

#     @POST("/api/content/tvnz/ondemand/login/{device}/j_tvnz_security_check?j_validate=true")
#     Observable<Response> m4067a(@Path("device") String str, @Body LoginDto loginDto);

#     @POST("/system/tvnz/odmail/sendVerificationEmail")
#     Observable<Response> m4068a(@Body ResendVerificationEmailDto resendVerificationEmailDto);

#     @POST("/system/tvnz/odmail")
#     Observable<Response> m4069b();

#     @GET("/api/session/tvnz/ondemand/my-shows/all.{device}.{api}.json")
#     Observable<SavedItemResponseDto> m4070b(@Path("device") String str, @Path("api") String str2);

#     @PUT("/api/session/tvnz/ondemand/my-shows/watchlist.{device}.{api}.json")
#     Observable<SavedItemResponseDto> m4071b(@Path("device") String str, @Path("api") String str2, @Body AssetPathDto assetPathDto);

#     @GET("/api/session/tvnz/ondemand/my-shows.{device}.{api}.json")
#     Observable<List<TvnzJsonObject>> m4072c(@Path("device") String str, @Path("api") String str2);

#     @DELETE_WITH_BODY("/api/session/tvnz/ondemand/my-shows/watchlist.{device}.{api}.json")
#     Observable<SavedItemResponseDto> m4073c(@Path("device") String str, @Path("api") String str2, @Body AssetPathDto assetPathDto);

#     @PUT("/api/session/tvnz/ondemand/my-shows/favourites.{device}.{api}.json")
#     Observable<SavedItemResponseDto> m4074d(@Path("device") String str, @Path("api") String str2, @Body AssetPathDto assetPathDto);

#     @DELETE_WITH_BODY("/api/session/tvnz/ondemand/my-shows/favourites.{device}.{api}.json")
#     Observable<SavedItemResponseDto> m4075e(@Path("device") String str, @Path("api") String str2, @Body AssetPathDto assetPathDto);

# @RestMethod(hasBody = true, value = "DELETE")
# @Target({ElementType.METHOD})
# @Retention(RetentionPolicy.RUNTIME)
# public @interface DELETE_WITH_BODY {
#     String value();
# }