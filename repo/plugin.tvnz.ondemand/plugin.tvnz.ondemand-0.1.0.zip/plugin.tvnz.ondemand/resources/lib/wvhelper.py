import os
import posixpath
import xbmc
import xbmcgui
import xbmcaddon
import platform
import requests

import config

system_ = platform.system()
arch = platform.machine()
if arch[:3] == 'arm':
    arch = arch[:5]

if system_ == 'Linux' and xbmc.getCondVisibility('system.platform.android'):
    system_ = 'Android'

if system_+arch in config.SUPPORTED_PLATFORMS:
    supported = True
    ssd_filename = config.SSD_WV_DICT[system_]
    widevinecdm_filename = config.WIDEVINECDM_DICT[system_]
else:
    supported = False

git_url = config.SSD_WV_REPO
cdm_path = None
addon = None

def check_inputstream(reinstall=False):
    global cdm_path, addon

    if not supported and config.__addon__.getSetting('skip_drm') != 'true':
        xbmcgui.Dialog().ok('Not Supported', 'This system is not supported for DRM content playback.')
        return False

    def get_addon():
        try:
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"inputstream.adaptive","enabled":false}}')
            xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"inputstream.adaptive","enabled":true}}')
            return xbmcaddon.Addon('inputstream.adaptive')
        except:
            return False

    addon = get_addon()
    if not addon:
        xbmc.executebuiltin('InstallAddon(inputstream.adaptive)', True)

        addon = get_addon()
        if not addon:
            xbmcgui.Dialog().ok('Missing inputstream.adaptive add-on',
                                'inputstream.adaptive VideoPlayer InputStream add-on \
                                not found or not enabled. This add-on is required to \
                                view DRM protected content.')
            return False

    cdm_path = xbmc.translatePath(addon.getSetting('DECRYPTERPATH')) 
    if not os.path.isdir(cdm_path):
        os.makedirs(cdm_path)

    if system_ == 'Android':
        return True

    try:
        installed = False

        if reinstall or not is_widevinecdm():
            get_widevinecdm()
            installed = True

        if reinstall or not is_ssd_wv():
            get_ssd_wv()
            installed = True
    except:
        xbmcgui.Dialog().ok('ERROR', 'There was an error checking / installing DRM.')
        return False

    if installed:
        xbmcgui.Dialog().ok('DRM has been installed.', 'If videos still won\'t play - please try restarting KODI.')

    return True

def is_widevinecdm():
    for file in os.listdir(cdm_path):
        if 'widevinecdm' in file:
            return True
    return False

def is_ssd_wv():
    for file in os.listdir(cdm_path):
        if 'ssd_wv' in file:
            return True

    return False
        
def get_widevinecdm():
    url = config.WIDEVINECDM_URL[system_+arch]
    filename = url.split('/')[-1]
    xbmc.log(filename, level=xbmc.LOGNOTICE)

    download_path = os.path.join(cdm_path, filename)
    if os.path.exists(download_path):
        os.remove(download_path)

    if not progress_download(url, download_path, widevinecdm_filename):
        return

    if system_+arch in config.UNARCHIVE_COMMAND:
        command = config.UNARCHIVE_COMMAND[system_+arch].format(filename, cdm_path, config.WIDEVINECDM_DICT[system_])
        os.system(command)

def get_ssd_wv():
    addon_path = xbmc.translatePath(addon.getAddonInfo('path')).decode("utf-8")
    addon_lib = os.path.join(addon_path, 'lib')
    download_path = os.path.join(cdm_path, ssd_filename)

    if os.path.exists(download_path):
        os.remove(download_path)

    if os.path.exists(addon_lib):
        for file in os.listdir(addon_lib):
            if 'ssd_wv' in file:
                os.symlink(os.path.join(addon_lib, file), download_path)
                os.chmod(download_path, 0755)
                return
        
    url = posixpath.join(git_url, system_, arch, ssd_filename)
    if not progress_download(url, download_path, ssd_filename):
        return
 
    os.chmod(download_path, 0755)
    
def progress_download(url, download_path, filename):
    xbmc.log('Downloading {0}'.format(url),xbmc.LOGNOTICE)
    try:
        res = requests.get(url, stream=True, verify=False)
        res.raise_for_status()
    except requests.exceptions.HTTPError:
        xbmcgui.Dialog().ok('Download failed', 'HTTP '+str(res.status_code)+' error')
        xbmc.log('Error retrieving {0}'.format(url), level=xbmc.LOGNOTICE)

        return False

    total_length = float(res.headers.get('content-length'))
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading {0}".format(filename),
              "Downloading File",url)

    with open(download_path, 'wb') as f:
        chunk_size = 1024
        downloaded = 0
        for chunk in res.iter_content(chunk_size=chunk_size):
            f.write(chunk)
            downloaded += len(chunk)
            percent = int(downloaded*100/total_length)
            if dp.iscanceled():
                dp.close()
                res.close()
            dp.update(percent)

    xbmc.log('Download {0} bytes complete, saved in {1}'.format(
                int(total_length), download_path),xbmc.LOGNOTICE)

    dp.close()
    return True