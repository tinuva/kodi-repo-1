import string
try:
    from urllib import quote #python2
except:
    from urllib.parse import quote #python3

import router
import config
import utils
from render import Render

class View(object):
    def __init__(self, api, router):
        self._api = api
        self._router = router
        self._render = Render.get_render()

    def menu(self):
        items = []
        menu = config.MENU

        if self._api.logged_in:
            menu.extend(config.LOGGED_IN)
        else:
            menu.extend(config.LOGGED_OUT) 

        for item in menu:
            image = item.get('image')
            items.append({
                'title' : item.get('title'),
                'url'   : self._router.get_route(item.get('url')),
                'images' : {'icon':image, 'thumb':image},
                'playable' : item.get('playable'),
                })

        self._render.items(items)

    def login(self, params):
        #get credentials from add-on settings
        username = None
        password = None

        if not username or not password:
            username = self._render.get_username()
            if username:
                password = self._render.get_password()

            if not username or not password:
                return

        if self._api.login(username, password):
            #if save enabled
                #self._render.save_credentials(username, password)
            self._render.refresh()
        else:
            self._render.error("Login failed\nPossibly wrong email / password combination?")

    def myshows(self, params):
        if params.get('remove'):
            url = '/session/tvnz/ondemand/my-shows/favourites'
            self._api.delete_path(url, {'assetPath': params.get('remove')}, True)
            return self._render.refresh()

        elif params.get('add'):
            url = '/session/tvnz/ondemand/my-shows/favourites'
            self._api.put_path(url, {'assetPath': params.get('add')}, True)
            return self._render.notifcation("Added to My Shows")

        belt = '/content/tvnz/ondemand/my-shows/jcr:content/contentArea/favouritesbelt'
        path = '{0}/999/0'.format(belt)
        content = self._api.get_path(path, True)
        if not content:
            # error
            return

        items = self._parse_content(content)
        for show in items:
            show['context'] = [
                ( 'Remove from My Shows', self._router.get_route({'action':'myshows', 'remove':show['path']}) ),
            ]

        self._render.items(items)

    def live(self, params):
        items = []
        menu = config.LIVE_MENU

        for item in menu:
            image = item.get('image')
            items.append({
                'title' : item.get('title'),
                'url'   : self._router.get_route(item.get('url')),
                'images' : {'icon':image, 'thumb':image},
                'playable' : item.get('playable'),
                })

        self._render.items(items)

    def logout(self, params):
        self._api.logout()
        self._render.refresh()

    # todo: make search like youtube add-on (last searches etc)
    def search(self):
        query = self._render.get_query()
        path = '/content/tvnz/ondemand/shows/search/{0}'.format(quote(query.strip()))
        content = self._api.get_path(path)
        items = self._parse_content(content)
        self._render.items(items)

    def play(self, params):
        if params.get("channel"):
            path = '/content/tvnz/ondemand/channels/{0}'.format(params.get("channel"))
            result = self._api.get_path(path)
            video = self._api.get_m3u8(result[0]['mainItem']['liveStreamUrl'].strip())
            data = {'url': video['url']}

        elif params.get("brightcoveId"):
            data = self._api.widevine_auth(params.get("brightcoveId"))
            if 'error' in data:
                return self._render.error(data['error'])

        else:
            return self._render.error("Non supported video.")

        self._render.play(data)

    def belt(self, belt):
        path = '{0}/999/0'.format(belt)
        content = self._api.get_path(path)
        items = self._parse_content(content)
        self._render.items(items)

    def show(self, params):
        PREFETCH = False #todo: make as add-on setting

        show_path = params.get('path')
        page = self._api.get_path(show_path)

        items = []
        for belt in page:
            if not belt or belt.get('beltType') != 'default':
                continue

            count = int(belt.get('size', 0))

            def clean_contents(contents):
                return [i for i in contents if i]

            contents = clean_contents(belt['contents'])
            if not contents or contents[0].get('showPath') != show_path:
                continue

            elif len(contents) < count and PREFETCH:
                path = '{0}/999/0'.format(belt.get('beltPath'))
                contents = clean_contents(self._api.get_path(path))

            episodes = []
            for episode in contents:
                episode = self._parse_episode(episode)
                if episode:
                    episodes.append(episode)

            if not episodes:
                continue

            items.append({
                'title' : "[B][COLOR yellow]** {0} **[/COLOR][/B]".format(belt['title']),
                'is_folder' : False,
                })

            items.extend(episodes)

            if len(contents) < count:
                items.append({
                    'title' : "More...",
                    'url'   : self._router.get_route({'action':'belt','path':belt.get('beltPath')})
                    })

        self._render.items(items)

    def genre(self, params):
        path = '/content/tvnz/ondemand/genre'
        page = self._api.get_path(path)

        items = []
        for belt in page:
            if belt.get('beltType') != 'default':
                continue

            items.append({
                'title' : belt.get('title'),
                'url'   : self._router.get_route({'action':'belt','path':belt.get('beltPath')})
                })

        self._render.items(items)

    def a_to_z(self):
        path = '/content/tvnz/ondemand/shows'
        page = self._api.get_path(path)

        items = []
        for belt in page:
            if belt.get('beltType') != 'default':
                continue

            items.append({
                'title' : belt.get('title'),
                'url'   : self._router.get_route({'action':'belt','path':belt.get('beltPath')})
                })

        self._render.items(items)

    def _parse_content(self, content):
        items = []
        for item in content:
            if not item: continue

            if item.get('brightcoveId'):
                items.append(self._parse_episode(item))
            elif item.get('path'):
                items.append(self._parse_show(item))

        return items

    def _parse_episode(self, episode):
        brightcoveId = episode.get('brightcoveId')
        if not brightcoveId:
            return None

        path = episode.get('path')

        title = episode.get('identifier2')
        if not title:
            title = episode.get('identifier3')
        if not title:
            title = episode.get('identifier1')

        image = episode.get('images',{}).get('default')

        if image:
            image = config.API_BASE_URL+image

        info = {
            'title': title,
            'originaltitle': title,
            'plot': episode.get('synopsis'), 
            'plotoutline': episode.get('synopsis'), 
            'duration': int(episode.get('duration'))/1000, 
            'aired': episode.get('broadCastDate'),
            'mediatype': 'episode',
            'tvshowtitle': episode.get('identifier1'),
        }

        try:
            info['episode'] = int(episode['eVar31'].split('-')[0].strip('e'))
            info['season'] = int(path.split('/')[-2].strip('s'))
        except:
            pass

        episode = {
                'title' : title,
                'url' : self._router.get_route({'action':'play', 'brightcoveId':brightcoveId}),
                'path' : path,
                'images' : {'thumb': image, 'icon': image},
                'playable' : True,
                'info' : info,
                }

        return episode

    def _parse_show(self, show):
        showId = show.get('showId')
        title = show.get('displayTitle')
        path = show.get('path')
        url = self._router.get_route({'action':'show', 'path':path})
        image = show.get('images',{}).get('default')
        if image:
            image = config.API_BASE_URL+image

        info = {
            'title': title,
            'originaltitle': title,
            'plot': show.get('synopsis'), 
            'plotoutline': show.get('synopsis'), 
            'mediatype': 'tvshow',
            'tvshowtitle': title,
        }

        show = {
            'id' : showId,
            'title' : title,
            'url'   : url,
            'images' : {'thumb': image, 'icon': image},
            'path' : path,
            'info' : info,
            }

        # if self._api.logged_in:
        #     show['context'] = [
        #         ( 'Add to My Shows', self._router.get_route({'action':'myshows', 'add':path}) ),
        #     ]

        return show

    def reinstall(self):
        self._render.reinstall()