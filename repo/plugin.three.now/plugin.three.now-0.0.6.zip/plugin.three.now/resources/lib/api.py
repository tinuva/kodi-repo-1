import requests
import os
import config
import re

try:
    import StringIO #python2
except:
    import io as StringIO #python3

class API(object):
    _url = config.API_BASE_URL+'/now-api/v3/{0}'

    def __init__(self):
        self._session = requests.Session()
        self._session.headers.update({
            'BCOV-POLICY': config.BRIGHTCOVE_KEY, 
            'X-Forwarded-For': config.X_FORWARD_IP
            })

    def widevine_auth(self, program_id):
        brightcove_url = config.BRIGHTCOVE_URL.format(config.BRIGHTCOVE_ACCOUNT, program_id)
        program_data = self._session.get(brightcove_url).json()
        print(program_data)

        if 'sources' not in program_data:
            return {'error': program_data[0]['message']}

        for source in program_data['sources']:
            if source.get('container') == None:
                if 'key_systems' in source:
                    if 'com.widevine.alpha' in source['key_systems']:
                        return {'url':source['src'], 'key':source['key_systems']['com.widevine.alpha']['license_url']}

        return {'error': 'Could not find DRM key'}

    def get_m3u8(self, video_id, max_bandwith=None):
        url = config.API_INFO_URL.format(video_id)
        data = self._session.get(url).json()

        response = self._session.get(data['HLSURL'])
        if response.status_code != requests.codes.ok:
            return {'error': 'Access denied. Possibly due to VPN / Overseas IP address.'}


        infile = StringIO.StringIO(response.text)
        if not infile.readline().lower().startswith('#extm3u'):
           return {'error': 'Error in video URL'}

        videos = []
        video = {}
        for line in infile:
            line=line.strip()

            if line.startswith('#EXT-X-STREAM-INF:'):
                # pull length and title from #EXTINF line
                pattern = re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
                params = pattern.split(line.replace('#EXT-X-STREAM-INF:', ''))[1::2]

                for param in params:
                    name, value = param.split('=', 1)
                    video[name.lower()] = value

            elif(line == '' or line.startswith('#')):
                continue

            else:
                video['url'] = line
                videos.append(video)
                video = {}

        videos = sorted(videos, key=lambda k: int(k.get('bandwidth', 0)), reverse=True)
        for video in videos:
            if max_bandwith == None or int(video.get('bandwidth'),0) <= max_bandwith:
                return {'url': video['url']}

        #all videos higher bandwith, so return the last in the list (lowest bandwith)
        return {'url': video['url']}

    def get_path(self, path):
        url = self._url.format(path)
        print(url)
        r = self._session.get(url)
        if r.text:
            return r.json()
        raise Exception("Error getting patch")