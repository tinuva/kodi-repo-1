import api

# Session Interface
class Session(object):
    def __init__(self):
        self._api = api.API()

    @property
    def api(self):
        return self._api