import os
import sys

import xbmc
import xbmcaddon

__addon__ = xbmcaddon.Addon()
cwd = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
BASE_RESOURCE_PATH = os.path.join(cwd, 'resources', 'lib')
DATA_PATH  = xbmc.translatePath(__addon__.getAddonInfo('profile'))
sys.path.append(BASE_RESOURCE_PATH)

import session
from router import Router

if __name__ == '__main__':
    session = session.Session()
    router = Router(session, sys.argv[0])
    router.route(sys.argv[2])