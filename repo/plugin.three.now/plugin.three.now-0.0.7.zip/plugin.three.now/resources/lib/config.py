KODI = True

MENU = [
  {'title':'Shows', 'url':{'action':'shows'}, 'image':None},
  {'title':'Live Channels', 'url':{'action':'live'}, 'image':None},
]

BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{0}/videos/{1}'
BRIGHTCOVE_KEY = 'BCpkADawqM2NDYVFYXV66rIDrq6i9YpFSTom-hlJ_pdoGkeWuItRDsn1Bhm7QVyQvFIF0OExqoywBvX5-aAFaxYHPlq9st-1mQ73ZONxFHTx0N7opvkHJYpbd_Hi1gJuPP5qCFxyxB8oevg-'
BRIGHTCOVE_ACCOUNT = '3812193411001'

X_FORWARD_IP = '54.66.183.81'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'

API_BASE_URL = 'http://now-api.mediaworks.nz'
API_INFO_URL = 'http://media-api.tv3.co.nz/brightcove/info/{0}'

SSD_WV_REPO = "https://bitbucket.org/matthuisman/decryptmodules/raw/master/"

WIDEVINECDM_URL = { 'Linuxx86_64': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Linux/x86_64/libwidevinecdm.so',
                    'Linuxarmv7': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Linux/armv7/libwidevinecdm.so',
                    'Linuxarmv8': 'https://bitbucket.org/matthuisman/decryptmodules/raw/master/Linux/armv8/libwidevinecdm.so'}

UNARCHIVE_COMMAND = { 'Linuxx86_64': "(cd {1} && chmod 755 {1}/{2})",
                      'Linuxarmv7': "(cd {1} && chmod 755 {1}/{2})",
                      'Linuxarmv8': "(cd {1} && chmod 755 {1}/{2})"}

SSD_WV_DICT = { 'Windows': 'ssd_wv.dll',
                'Linux': 'libssd_wv.so',
                'Darwin': 'libssd_wv.dylib'}

WIDEVINECDM_DICT = { 'Windows': 'widevinecdm.dll',
                     'Linux': 'libwidevinecdm.so',
                     'Darwin': 'libwidevinecdm.dylib'}
                     
SUPPORTED_PLATFORMS = [ 'WindowsAMD64',
                        'Windowsx86',
                        'Darwinx86_64',
                        'Linuxx86_64',
                        'Linuxarmv7',
                        'Linuxarmv8']

XML_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?><request protocol="3.0" 
version="chrome-55.0.2883.87" prodversion="55.0.2883.87" requestid="{{{0}}}" 
lang="en-US" updaterchannel="" prodchannel="" os="{1}" arch="{2}" 
nacl_arch="x86-64" wow64="1"><hw physmemory="12"/><os platform="Windows" 
arch="x86_64" version="10.0.0"/><app appid="oimompecagnajdejgnnjijobebaeigek" 
version="0.0.0.0" installsource="ondemand"><updatecheck/><ping rd="-2" 
ping_freshness=""/></app></request>"""

CRX_UPDATE_URL = "https://clients2.google.com/service/update2?cup2key=6:{0}&cup2hreq={1}"


# SSD_WV_REPO = "https://github.com/glennguy/decryptmodules/raw/master/"

# WIDEVINECDM_URL = { 'Linuxx86_64': 'http://www.slimjetbrowser.com/chrome/lnx/chrome64_55.0.2883.75.deb',
#                     'Linuxarmv7': 'http://odroidxu.leeharris.me.uk/xu3/chromium-widevine-1.4.8.823-2-armv7h.pkg.tar.xz',
#                     'Linuxarmv8': 'http://odroidxu.leeharris.me.uk/xu3/chromium-widevine-1.4.8.823-2-armv7h.pkg.tar.xz'}

# UNARCHIVE_COMMAND = { 'Linuxx86_64': "(cd {1} && ar x {0} data.tar.xz && tar xJfO data.tar.xz ./opt/google/chrome/libwidevinecdm.so >{1}/{2} && chmod 755 {1}/{2} && rm -f data.tar.xz {0})",
#                       'Linuxarmv7': "(cd {1} && tar xJfO {0} usr/lib/chromium/libwidevinecdm.so >{1}/{2} && chmod 755 {1}/{2} && rm -f {0})",
#                       'Linuxarmv8': "(cd {1} && tar xJfO {0} usr/lib/chromium/libwidevinecdm.so >{1}/{2} && chmod 755 {1}/{2} && rm -f {0})"}