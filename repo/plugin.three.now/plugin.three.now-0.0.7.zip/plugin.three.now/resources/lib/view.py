import router
import config
from render import Render

class View(object):
    def __init__(self, session, router):
        self._session = session
        self._router = router
        self._render = Render.get_render(config.KODI)

    def menu(self, params):
        items = []
        for item in config.MENU:
            image = item.get('image')
            items.append({
                'title' : item.get('title'),
                'url'   : self._router.get_route(item.get('url')),
                'images' : {'icon':image, 'thumb':image},
                'playable' : item.get('playable'),
                })
        self._render.items(items)

    def live(self, params):
        items = []

        result = self._session.api.get_path('live-epg')
        for channel in result['channels']:
            items.append(self._parse_channel(channel))

        self._render.items(items)

    def play(self, params):
        if int(params.get("drm", 0)) == 1:
            data = self._session.api.widevine_auth(params.get("vid"))
        else:
            data = self._session.api.get_m3u8(params.get("vid"))

        if 'error' in data:
            return self._render.error(data['error'])

        self._render.play(data)

    def shows(self, params):
        items = []

        result = self._session.api.get_path('shows')
        for show in result['shows']:
            items.append(self._parse_show(show))

        self._render.items(items)

    def episodes(self, params):
        items = []

        result = self._session.api.get_path('show/{0}'.format(params.get('show')))
        show = result['show']
        for episode in show['episodes']:
            items.append(self._parse_episode(episode))

        self._render.items(items)

    def reinstall(self, params):
        self._render.reinstall()

    def _has_drm(self, drmOptions):
        if drmOptions['widevineClassic']['enabled'] and not drmOptions['widevineClassic']['licenseUrl']:
            return False
        elif drmOptions['widevineModular']['enabled'] and not drmOptions['widevineModular']['licenseUrl']:
            return False
        return True

    def _parse_channel(self, channel):
        title = channel.get('displayName')
        image = channel.get('logo').replace('[width]', '300')
        videoid = channel['videoRenditions']['videoCloud']['brightcoveId']

        info = {
            'duration': 0, 
            'playcount': 0,
            'mediatype': 'video',
        }

        channel = {
                'title' : title,
                'url' : self._router.get_route({'action': 'play', 'vid': videoid, 'drm': 0}),
                'images' : {'thumb': image, 'icon': image, 'fanart': channel.get('logo')},
                'playable' : True,
                'info' : info,
                }

        return channel

    def _parse_episode(self, episode):
        title = episode.get('name')
        videoid = episode['videoRenditions']['videoCloud']['brightcoveId']
        drm = self._has_drm(episode['videoRenditions']['videoCloud']['drmOptions'])
        image = episode.get('images',{}).get('videoTile','').replace('[width]', '300')

        info = {
            'genre': episode.get('genre'), 
            'plot': episode.get('synopsis'), 
            'plotoutline': episode.get('synopsis'), 
            'duration': int(episode.get('duration')), 
            'aired': episode.get('airedDate'),
            'mediatype': 'episode',
            'tvshowtitle': episode.get('showTitle'),
        }

        try:
            info.update({
                'episode': int(episode.get('episode')), 
                'season': int(episode.get('season')),
                })
        except:
            pass

        episode = {
                'title' : title,
                'url' : self._router.get_route({'action': 'play', 'vid': videoid, 'drm': int(drm)}),
                'images' : {'thumb': image, 'icon': image},
                'playable' : True,
                'info' : info,
                }

        return episode

    def _parse_show(self, show):
        showId = show.get('showId')
        title = show.get('name')
        url = self._router.get_route({'action':'episodes','show':showId})
        image = show.get('images',{}).get('showTile','').replace('[width]', '300')
        fanart = show.get('images',{}).get('showHero','')

        info = {
            'plot': show.get('synopsis'), 
            'plotoutline': show.get('synopsis'), 
            'mediatype': 'tvshow',
            'tvshowtitle': title,
        }

        show = {
            'id' : showId,
            'title' : title,
            'url'   : url,
            'images' : {'thumb': image, 'icon': image, 'fanart': fanart},
            'fanart' : fanart,
            'info' : info,
            }

        return show