import os
import sys

cwd = '.'
BASE_RESOURCE_PATH = os.path.join(cwd, 'resources', 'lib')
sys.path.append(BASE_RESOURCE_PATH)

import session
from router import Router

if __name__ == '__main__':
    import config
    config.KODI = False
    session = session.Session()
    router = Router(session, '')

  #  router.route('')
    router.route('?action=live')
    #router.route('?vid=4835187443001&action=play&drm=0')
    #router.route('?action=shows')
    #router.route('?action=episodes&show=118499')
    #router.route('?vid=5394386479001&drm=0&action=play')