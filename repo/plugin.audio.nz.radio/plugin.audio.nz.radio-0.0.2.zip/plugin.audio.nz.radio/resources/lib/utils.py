import requests
import re
try:
    import StringIO #python2
except:
    import io as StringIO #python3

def get_streams(URL):
    response = requests.get(URL)
    if response.status_code != requests.codes.ok:
        return {'error': 'Error getting M3U8 file'}


    infile = StringIO.StringIO(response.text)
    if not infile.readline().lower().startswith('#extm3u'):
       return {'error': 'Invalid M3U8 file'}

    streams = []
    stream = {}

    info_pattern = re.compile(r'([^\s]+)="([^\s]+)"')
    url_pattern = re.compile(r'-i ([^\s]+)')
    for line in infile:
        line=line.strip()

        if line.startswith('#EXTINF:'):
            params, name = line.replace('#EXTINF:', '').split(',')
            stream['name'] = name

            for (key, param) in info_pattern.findall(params):
                if key == 'tvg-logo':
                    stream['image'] = param

        elif(line == '' or line.startswith('#')):
            continue

        else:
            url = url_pattern.findall(line)
            if not url:
                continue
                
            stream['url'] = url[0]
            streams.append(stream)
            stream = {}

    return streams