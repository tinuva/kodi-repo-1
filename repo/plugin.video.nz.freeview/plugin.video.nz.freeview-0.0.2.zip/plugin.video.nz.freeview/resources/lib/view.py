import requests
import json
import time
import os

import router
import config
from render import Render

class View(object):
    def __init__(self, router):
        self._router = router
        self._render = Render.get_render()

    def menu(self, params):
        items = []

        streams = self._get_streams()
        for stream in streams:
            items.append(self._parse_stream(stream))

        self._render.items(items)

    def clear_cache(self, params):
        try:
            os.remove(config.CACHE_FILE)
        except:
            pass
        self._render.notifcation("Cached cleared.")

    def _get_streams(self):
        try:
            with open(config.CACHE_FILE, 'r') as f:
                data = json.load(f)

            if data[-1] <= time.time():
                raise Exception("Cache Expired")

            return data[:-1]
        except:
            pass

        try:
            data = requests.get(config.DATA_FILE, timeout=3).json()
            data = sorted(data, key=lambda k: k['channel'])
        except:
            return []

        data.append(time.time() + config.CACHE_TIME)
        with open(config.CACHE_FILE, 'w') as f:
            f.write(json.dumps(data, separators=(',',':')))

        return data[:-1]

    def _parse_stream(self, stream):
        title = stream.get('name')
        image = stream.get('icon')

        info = {
            'title': title,
            'originaltitle': title,
            'plot': stream.get('description',''),
            'mediatype': 'video',
            'duration': 0, 
            'playcount': 0,
        }

        stream = {
                'title' : title,
                'url' : self._router.get_route({'action': 'play', 'url': stream.get('url')}),
                'images' : {'thumb': image, 'icon': image},
                'playable' : True,
                'info' : info,
                'video': stream.get('video',{}),
                'audio': stream.get('audio',{}),
                }

        return stream

    def play(self, params):
        data = {'url': params.get('url')}
        self._render.play(data)
